<?php

use Illuminate\Database\Seeder;

class WebsiteTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Let's truncate our existing records to start from scratch.

        DB::table('website')->insert([
            'name' => "Google",
            'url' => "http://www.google.com"
        ]);
        DB::table('website')->insert([
            'name' => "Facebook",
            'url' => "http://www.facebook.com"
        ]);
        DB::table('website')->insert([
            'name' => "Twitter",
            'url' => "http://www.twitter.com"
        ]);
        DB::table('website')->insert([
            'name' => "linkedin",
            'url' => "http://www.linkedin.com"
        ]);

    }
}
