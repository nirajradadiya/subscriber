<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;


class Website extends Model
{
    use SoftDeletes;

    protected $table = 'website';

    protected $dates = ['deleted_at'];

    protected $fillable = ['name', 'url'];
}
