<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WebsiteSubscriber extends Model
{
    use SoftDeletes;

    protected $table = 'website_subscriber';

    protected $dates = ['deleted_at'];

    protected $fillable = ['website_id', 'user_id'];


    public function Website(){
        return $this->belongsTo(Website::class, 'website_id', 'id');
    }

    public function users(){
        return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
