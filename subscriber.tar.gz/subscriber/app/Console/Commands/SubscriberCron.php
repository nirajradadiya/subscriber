<?php

namespace App\Console\Commands;

use App\WebsitePost;
use App\WebsiteSubscriber;
use Illuminate\Console\Command;

class SubscriberCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'subscriber:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        //Get latest Post with notification sent = 'No'
        $postDetail = WebsitePost::where('is_notification_sent','=','No')->first();

        //Get list of users who will receive notifcaition
        WebsiteSubscriber::where('website_id','=',$postDetail->website_id)->chunk(100, function ($notificationUser,$postDetail) {
            foreach ($notificationUser as $notifiUser) {

                Mail::send('emails.subscriber', ['user' => $notifiUser,'post'=>$postDetail], function ($m) use ($notifiUser) {
                    $m->from('hello@app.com', 'Subscrip');
                    $m->to($notifiUser->users->email, $notifiUser->users->name)->subject($postDetail->title);
                });
            }
        });

        // Update staus of recent post with notification sent YES

        $postDetail->is_notification_sent = 'Yes';
        $postDetail->save();
    }
}
