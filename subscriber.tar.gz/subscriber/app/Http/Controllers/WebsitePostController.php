<?php

namespace App\Http\Controllers;

use App\WebsitePost;
use Illuminate\Http\Request;

class WebsitePostController extends Controller
{

    public function index()
    {

        $WebsitePost = WebsitePost::all();
        return response()->json($WebsitePost);

    }

    public function show($id)
    {
        $website = WebsitePost::findOrFail($id);

        return $website;
    }

    public function store(Request $request)
    {

        $request->validate([
            'title' => 'required|max:255',
            'description' => 'required',
            'website_id' => 'required',
        ]);

        $WebsitePost = new WebsitePost([
            'website_id' => $request->get('website_id'),
            'title' => $request->get('title'),
            'description' => $request->get('description')
        ]);

        $WebsitePost->save();

        return response()->json($WebsitePost, 201);
    }

    public function update(Request $request, $id)
    {

        $WebsitePost = WebsitePost::findOrFail($id);

        $request->validate([
            'title' => 'required|max:255',
            'description' => 'required'
        ]);

        $WebsitePost->title = $request->get('title');
        $WebsitePost->description = $request->get('description');

        $WebsitePost->save();

        return response()->json($WebsitePost);
    }

    public function delete($id)
    {
        $websitePost = WebsitePost::findOrFail($id);
        $websitePost->delete();

        return response()->json(null, 204);
    }
}
