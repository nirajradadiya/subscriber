<?php

namespace App\Http\Controllers;

use App\WebsiteSubscriber;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class WebsiteSubscriberController extends Controller
{

    public function index()
    {

        $WebsitePost = WebsiteSubscriber::all();
        return response()->json($WebsitePost);

    }

    public function show($id)
    {
        $website = WebsiteSubscriber::findOrFail($id);

        return $website;
    }

    public function store(Request $request)
    {
        $request->validate([
            'user_id' => ['required', Rule::unique('website_subscriber')->where(function ($query) use ($request) {
                return $query->where('website_id', $request->website_id);
            })],
            'website_id' => 'required'
        ]);

        $WebsitePost = new WebsiteSubscriber([
            'website_id' => $request->get('website_id'),
            'user_id' => $request->get('user_id')
        ]);

        $WebsitePost->save();

        return response()->json($WebsitePost, 201);
    }

    public function delete($id)
    {
        $websitePost = WebsiteSubscriber::findOrFail($id);
        $websitePost->delete();

        return response()->json(null, 204);
    }
}
