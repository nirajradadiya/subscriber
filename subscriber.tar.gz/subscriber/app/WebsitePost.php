<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class WebsitePost extends Model
{
    use SoftDeletes;

    protected $table = 'website_post';

    protected $dates = ['deleted_at'];

    protected $fillable = ['website_id', 'title', 'description'];


    public function Website(){
        return $this->belongsTo(Website::class, 'website_id', 'id');
    }
}
